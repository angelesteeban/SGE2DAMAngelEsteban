# Act 11

def substring_test(s1, s2):
    """Comprueba si dos cadenas tienen alguna subcadena de dos caracteres en común.

    Args
    ----
    s1 (str)
        Primera cadena de texto que se quiere comprobar.

    s2 (str)
        Segunda cadena de texto que se quiere comprobar.

    Returns
    -------
    bool
        Devuelve True si encuentra al menos una subcadena de dos caracteres
        consecutivos de s1 que también aparezca en s2.
        Devuelve False si no encuentra ninguna coincidencia.

    """
    # Convierte las dos cadenas a minúsculas para que la comparación
    # no distinga entre mayúsculas y minúsculas.
    s1, s2 = s1.lower(), s2.lower()

    # Recorre s1 creando subcadenas de dos caracteres consecutivos.
    # s1[i:i+2] obtiene dos caracteres desde la posición i.
    # range(len(s1) - 1) permite recorrer las posiciones
    # donde todavía se pueden obtener dos caracteres.
    # Comprueba si cada subcadena aparece dentro de s2.
    # any() devuelve True si al menos una de las comprobaciones es True.
    return any(s1[i:i+2] in s2 for i in range(len(s1) - 1))