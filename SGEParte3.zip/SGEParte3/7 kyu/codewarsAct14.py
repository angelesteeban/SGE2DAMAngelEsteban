# Act 14

def get_sum(a, b):
    """Calcula la suma de todos los números enteros entre a y b, incluidos ambos.

    Args
    ----
    a (int)
        Primer número entero que indica el inicio del intervalo.

    b (int)
        Segundo número entero que indica el final del intervalo.

    Returns
    -------
    int
        Devuelve la suma de todos los números enteros comprendidos
        entre el menor y el mayor de los dos argumentos, incluidos ambos.
    """

    # Obtiene el menor de los dos números, independientemente del orden.
    menor = min(a, b)

    # Obtiene el mayor de los dos números, independientemente del orden.
    mayor = max(a, b)

    # Inicializa la variable total en 0.
    # En ella se acumulará la suma de los números.
    total = 0

    # Recorre todos los números enteros desde menor hasta mayor,
    # incluyendo también el valor de mayor gracias a mayor + 1.
    for n in range(menor, mayor + 1):

        # Suma el número actual n al valor acumulado en total.
        total += n

    # Devuelve la suma total calculada.
    return total