# Act 15

def descending_order(num):
    """Ordena los dígitos de un número de mayor a menor.

    Args
    ----
    num (int)
        Número entero cuyos dígitos se quieren ordenar de mayor a menor.

    Returns
    -------
    int
        Devuelve un número entero formado por los mismos dígitos
        que num, ordenados de mayor a menor.
    """

    # Convierte el número entero num en una cadena de texto (str).
    # sorted() separa sus caracteres y los ordena.
    # reverse=True indica que el orden debe ser descendente,
    # es decir, desde el dígito mayor hasta el menor.
    # El resultado se guarda en una lista llamada digitos.
    digitos = sorted(str(num), reverse=True)

    # Une todos los dígitos de la lista en una única cadena de texto.
    # "".join(digitos) utiliza una cadena vacía como separador,
    # por lo que los dígitos quedan unidos sin espacios ni símbolos.
    # int() convierte la cadena resultante en un número entero.
    resultado = int("".join(digitos))

    # Devuelve el número entero con sus dígitos ordenados de mayor a menor.
    return resultado