# Act 12

def row_sum_odd_numbers(n):
    """Calcula la suma de los números impares de la fila n de un triángulo numérico.

    Args
    ----
    n (int)
        Número entero positivo que indica la fila del triángulo.

    Returns
    -------
    int
        Devuelve la suma de todos los números impares de la fila n.
        El resultado se calcula elevando n al cubo (n ** 3).
    """

    # Eleva n al cubo, es decir, multiplica n por sí mismo tres veces.
    # Este cálculo permite obtener la suma de los números impares de la fila n.
    return n ** 3