# Act 13

def friend(x):
    """Filtra una lista de nombres y devuelve los que tienen exactamente 4 caracteres.

    Args
    ----
    x (list)
        Lista de nombres en formato String (str) que se quieren comprobar.

    Returns
    -------
    list
        Devuelve una nueva lista que contiene únicamente los nombres
        que tienen exactamente 4 caracteres.
    """

    # Crea una lista vacía donde se guardarán los nombres que cumplan la condición.
    amigos = []

    # Recorre cada nombre de la lista x.
    for name in x:

        # Comprueba si la longitud del nombre es exactamente 4 caracteres.
        if len(name) == 4:

            # Añade el nombre a la lista amigos si tiene 4 caracteres.
            amigos.append(name)

    # Devuelve la lista con los nombres que cumplen la condición.
    return amigos