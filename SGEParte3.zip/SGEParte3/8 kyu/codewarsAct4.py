# Act 4

def boolean_to_string(b):
    """Convierte un valor booleano en una cadena de texto.

    Args
    ----
    b (bool)
        Valor booleano que puede ser True o False.

    Returns
    -------
    str
        Devuelve la cadena "True" si b es True.
        Devuelve la cadena "False" si b es False.
    """

    resultado = ""
    if (b == True):
        resultado = "True"
    if (b == False):
        resultado = "False"
    return resultado