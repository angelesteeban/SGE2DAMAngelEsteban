# Act 10

import re  # Importa el módulo re para trabajar con expresiones regulares.

def is_digit(n):
    """Comprueba si una cadena contiene exactamente un dígito numérico.

    Args
    ----
    n (str)
        Cadena de texto que se quiere comprobar.
        Debe contener exactamente un carácter numérico del 0 al 9.

    Returns
    -------
    bool
        Devuelve True si la cadena contiene exactamente un dígito del 0 al 9.
        Devuelve False si está vacía, contiene varios caracteres
        o incluye letras, espacios u otros símbolos.
    """
    # re.fullmatch() comprueba si toda la cadena coincide con el patrón.
    # r"[0-9]" indica que debe haber exactamente un dígito del 0 al 9.
    # bool() convierte el resultado en un valor booleano:
    # True si hay coincidencia y False si no la hay.
    return bool(re.fullmatch(r"[0-9]", n))