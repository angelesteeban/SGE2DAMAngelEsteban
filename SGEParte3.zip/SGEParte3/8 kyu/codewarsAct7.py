# Act 7

def past(h, m, s):
    """Convierte una hora, formada por horas, minutos y segundos, a milisegundos.

    Args
    ----
    h (int)
        Número de horas.

    m (int)
        Número de minutos.

    s (int)
        Número de segundos.

    Returns
    -------
    int
        Devuelve el tiempo total en milisegundos.
        Multiplica las horas por 3600 para convertirlas a segundos,
        los minutos por 60 para convertirlos a segundos y suma los segundos.
        Finalmente, multiplica el total por 1000 para convertirlo a milisegundos.
    """
    return (h * 3600 + m * 60 + s) * 1000