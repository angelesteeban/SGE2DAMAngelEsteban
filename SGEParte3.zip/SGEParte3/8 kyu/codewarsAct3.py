# Act 3

def make_upper_case(s):
    """Convierte una cadena de texto a mayúsculas.

    Args
    ----
    s (str)
        Cadena de texto que se quiere convertir a mayúsculas.

    Returns
    -------
    str
        Devuelve una nueva cadena de texto con todas las letras en mayúsculas.
    """

    resultado = s.upper()
    return resultado