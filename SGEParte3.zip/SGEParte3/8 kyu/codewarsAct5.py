# Act 5

def multiply(a, b):
    """Originalmente este código era:

    def multiply(a, b):
    a*b

    Este código carecía de return por lo que lo hemos arreglado aquí.

    Args
    ----
    a (int)
        Primer número entero que se quiere multiplicar.

    b (int)
        Segundo número entero que se quiere multiplicar.

    Returns
    -------
    int
        Devuelve el resultado de multiplicar a por b.
    """

    return a * b