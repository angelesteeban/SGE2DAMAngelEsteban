# Act 6

def greet():
    """Devuelve un saludo.

    Args
    ----
    Esta función no recibe argumentos.

    Returns
    -------
    str
        Devuelve la cadena de texto "hello world!".
    """

    hola = "hello world!"
    return hola