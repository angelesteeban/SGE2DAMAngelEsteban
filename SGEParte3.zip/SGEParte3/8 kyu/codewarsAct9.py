# Act 9

def add_extra(list_of_numbers):
    """Crea una copia de una lista y añade el número 13 al final.

    Args
    ----
    list_of_numbers (list)
        Lista de números a la que se quiere añadir el número 13.
        La lista original no se modifica, ya que se trabaja con una copia.

    Returns
    -------
    list
        Devuelve una nueva lista que contiene todos los elementos
        de la lista original y el número 13 al final.
    """

    # Crea una copia de la lista original para no modificarla.
    new_list = list_of_numbers.copy()

    # Añade el número entero 13 al final de la nueva lista.
    new_list.append(13)

    # Devuelve la nueva lista con el número 13 añadido.
    return new_list