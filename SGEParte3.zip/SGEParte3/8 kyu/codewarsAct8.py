# Act 8

def century(year):
    """Calcula el siglo al que pertenece un año.

    Args
    ----
    year (int)
        Año del que se quiere calcular el siglo.

    Returns
    -------
    int
        Devuelve el siglo al que pertenece el año.
        Suma 99 al año y realiza una división entera entre 100
        para redondear el resultado hacia arriba al siglo correspondiente.
    """
    return (year + 99) // 100