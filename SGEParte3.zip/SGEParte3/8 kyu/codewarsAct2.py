# Act 2

def repeat_str(repeat, string):
    """Repite una cadena de texto un número determinado de veces.

    Args
    ----
    repeat (int)
        Número de veces que se quiere repetir la cadena.

    string (str)
        Cadena de texto que se quiere repetir.

    Returns
    -------
    str
        Devuelve la cadena de texto repetida tantas veces como indique repeat.
    """

    resultado = string * repeat

    return resultado