# Act 1

resultado = ""

def par_o_impar(numero):
    """Comprueba si un número es par o impar.

    Args
    ----
    numero (int)
        Número entero que se quiere comprobar.

    Returns
    -------
    str
        Devuelve "Par" si el número es divisible entre 2.
        Devuelve "Impar" si el número no es divisible entre 2.
    """

    resultado = ""
    if (numero % 2 == 0):
        resultado = "Par"
    if (numero % 2 != 0):
        resultado = "Impar"
    return resultado