# Ángel Esteban Parra
# Main para probar todas las actividades de Codewars
# Carpetas: 7 kyu y 8 kyu

# Importamos importlib para cargar los archivos Python mediante sus rutas.
import importlib.util
from pathlib import Path


# Obtenemos la ruta de la carpeta donde se encuentra este archivo main.py.
BASE_DIR = Path(__file__).parent


# Función auxiliar para cargar un archivo Python desde una ruta.
def cargar_modulo(ruta, nombre_modulo):
    """Carga un archivo Python y devuelve su módulo.

    Args
    ----
    ruta (Path)
        Ruta del archivo Python que se quiere cargar.

    nombre_modulo (str)
        Nombre que se utilizará para identificar el módulo.

    Returns
    -------
    module
        Devuelve el módulo cargado para poder utilizar sus funciones.
    """
    # Crea la especificación del módulo a partir de la ruta del archivo.
    spec = importlib.util.spec_from_file_location(nombre_modulo, ruta)

    # Crea el módulo a partir de la especificación.
    modulo = importlib.util.module_from_spec(spec)

    # Ejecuta el contenido del archivo Python.
    spec.loader.exec_module(modulo)

    # Devuelve el módulo cargado.
    return modulo


# ACTIVIDADES DE 8 KYU

print("ACTIVIDADES 8 KYU")


# Act 1: Comprobar si un número es par o impar.
act8_1 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct1.py", "act8_1"
)

print("Act 1: Par o impar")
print(act8_1.par_o_impar(1))  # Impar
print(act8_1.par_o_impar(2))  # Par


# Act 2: Repetir una cadena de texto.
act8_2 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct2.py", "act8_2"
)

print("Act 2: Repetir texto")
print(act8_2.repeat_str(4, "Hola"))  # HolaHolaHolaHola


# Act 3: Convertir una cadena a mayúsculas.
act8_3 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct3.py", "act8_3"
)

print("Act 3: Convertir a mayúsculas")
print(act8_3.make_upper_case("hola"))  # HOLA


# Act 4: Convertir un booleano a String.
act8_4 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct4.py", "act8_4"
)

print("Act 4: Booleano a String")
print(act8_4.boolean_to_string(True))   # True
print(act8_4.boolean_to_string(False))  # False


# Act 5: Multiplicar dos números.
act8_5 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct5.py", "act8_5"
)

print("Act 5: Multiplicación")
print(act8_5.multiply(2, 2))  # 4


# Act 6: Devolver un saludo.
act8_6 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct6.py", "act8_6"
)

print("Act 6: Saludo")
print(act8_6.greet())  # hello world!


# Act 7: Convertir horas, minutos y segundos a milisegundos.
act8_7 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct7.py", "act8_7"
)

print("Act 7: Tiempo en milisegundos")
print(act8_7.past(1, 1, 1))  # 3661000


# Act 8: Calcular el siglo de un año.
act8_8 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct8.py", "act8_8"
)

print("Act 8: Calcular siglo")
print(act8_8.century(1705))  # 18
print(act8_8.century(2000))  # 20
print(act8_8.century(2001))  # 21


# Act 9: Añadir el número 13 a una copia de una lista.
act8_9 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct9.py", "act8_9"
)

print("Act 9: Añadir 13 a una lista")
numeros = [1, 2, 3, 4]
print(act8_9.add_extra(numeros))  # [1, 2, 3, 4, 13]
print(numeros)                    # [1, 2, 3, 4]


# Act 10: Comprobar si una cadena contiene un único dígito.
act8_10 = cargar_modulo(
    BASE_DIR / "8 kyu" / "codewarsAct10.py", "act8_10"
)

print("Act 10: Comprobar dígito")
print(act8_10.is_digit("5"))   # True
print(act8_10.is_digit("12"))  # False
print(act8_10.is_digit("a"))   # False


# ACTIVIDADES DE 7 KYU

print("ACTIVIDADES 7 KYU")


# Act 11: Comprobar si dos cadenas comparten una subcadena.
act7_11 = cargar_modulo(
    BASE_DIR / "7 kyu" / "codewarsAct11.py", "act7_11"
)

print("Act 11: Subcadena común")
print(act7_11.substring_test("hello", "world"))  # True
print(act7_11.substring_test("abc", "xyz"))      # False


# Act 12: Sumar los números impares de una fila.
act7_12 = cargar_modulo(
    BASE_DIR / "7 kyu" / "codewarsAct12.py", "act7_12"
)

print("Act 12: Suma de números impares")
print(act7_12.row_sum_odd_numbers(1))  # 1
print(act7_12.row_sum_odd_numbers(2))  # 8
print(act7_12.row_sum_odd_numbers(3))  # 27


# Act 13: Obtener los nombres que tienen 4 caracteres.
act7_13 = cargar_modulo(
    BASE_DIR / "7 kyu" / "codewarsAct13.py", "act7_13"
)

print("Act 13: Filtrar amigos")
print(act7_13.friend(["Ryan", "Kieran", "Jason", "Yous"]))
# ['Ryan', 'Yous']


# Act 14: Sumar todos los números entre dos valores.
act7_14 = cargar_modulo(
    BASE_DIR / "7 kyu" / "codewarsAct14.py", "act7_14"
)

print("Act 14: Suma entre dos números")
print(act7_14.get_sum(1, 3))    # 6
print(act7_14.get_sum(5, 5))    # 5
print(act7_14.get_sum(3, 1))    # 6


# Act 15: Ordenar los dígitos de un número de mayor a menor.
act7_15 = cargar_modulo(
    BASE_DIR / "7 kyu" / "codewarsAct15.py", "act7_15"
)

print("Act 15: Orden descendente")
print(act7_15.descending_order(42145))   # 54421
print(act7_15.descending_order(145263))  # 654321


print("TODAS LAS PRUEBAS HAN TERMINADO")

