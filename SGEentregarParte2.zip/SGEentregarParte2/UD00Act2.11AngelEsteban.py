# ACTIVIDAD 11 - INTERFAZ GRÁFICA CON KIVY

# Importamos hashlib para poder calcular el SHA1
# de la contraseña que escribe el usuario.
import hashlib

# Importamos csv para poder leer el archivo users.csv.
import csv

# Importamos App, que es la clase principal de Kivy
# para crear una aplicación.
from kivy.app import App

# BoxLayout permite colocar los elementos de la ventana
# uno debajo de otro.
from kivy.uix.boxlayout import BoxLayout

# Label sirve para mostrar textos.
from kivy.uix.label import Label

# TextInput sirve para que el usuario pueda escribir.
from kivy.uix.textinput import TextInput

# Button sirve para crear el botón.
from kivy.uix.button import Button


# CLASE PRINCIPAL DE LA APLICACIÓN

class LoginApp(App):

    # build() crea la ventana y todos sus elementos.

    def build(self):

        # Creamos un diccionario donde guardaremos:
        # usuario -> contraseña SHA1
        self.usuarios = {}

        # Abrimos el archivo users.csv.
        with open("users.csv", "r", encoding="utf-8") as archivo:

            # Leemos el archivo usando ":" como separador,
            # porque el ejercicio tiene este formato:
            # "usuario":"passwordenSHA1"
            lector = csv.reader(archivo, delimiter=":")

            # Recorremos todas las líneas del archivo.
            for fila in lector:

                # Comprobamos que la línea tenga usuario y contraseña.
                if len(fila) >= 2:

                    # Quitamos espacios y comillas del usuario.
                    usuario = fila[0].strip().strip('"')

                    # Quitamos espacios y comillas del SHA1.
                    password_sha1 = fila[1].strip().strip('"')

                    # Guardamos el usuario y su SHA1.
                    self.usuarios[usuario] = password_sha1

        # Creamos el contenedor principal.
        # Los elementos se colocarán verticalmente.
        layout = BoxLayout(
            orientation="vertical",
            padding=20,
            spacing=10
        )

        # Creamos la etiqueta "Usuario".
        etiqueta_usuario = Label(
            text="Usuario"
        )

        # Creamos el campo donde el usuario escribirá
        # su nombre de usuario.
        self.campo_usuario = TextInput(
            multiline=False
        )

        # Creamos la etiqueta "Contraseña".
        etiqueta_password = Label(
            text="Contraseña"
        )

        # Creamos el campo para introducir la contraseña.
        
        # password=True hace que los caracteres aparezcan
        # ocultos.
        self.campo_password = TextInput(
            multiline=False,
            password=True
        )

        # Creamos el botón.
        boton = Button(
            text="COMPROBAR"
        )

        # Cuando se pulse el botón, llamaremos al método
        # comprobar_usuario().
        boton.bind(
            on_press=self.comprobar_usuario
        )

        # Creamos una etiqueta vacía.
        # Aquí mostraremos "OK" o "ERROR".
        self.resultado = Label(
            text=""
        )

        # Añadimos la etiqueta Usuario a la ventana.
        layout.add_widget(etiqueta_usuario)

        # Añadimos el campo de usuario.
        layout.add_widget(self.campo_usuario)

        # Añadimos la etiqueta Contraseña.
        layout.add_widget(etiqueta_password)

        # Añadimos el campo de contraseña.
        layout.add_widget(self.campo_password)

        # Añadimos el botón.
        layout.add_widget(boton)

        # Añadimos la etiqueta donde aparecerá
        # OK o ERROR.
        layout.add_widget(self.resultado)

        # Devolvemos el diseño completo de la ventana.
        return layout

    # Este método se ejecuta cuando pulsamos COMPROBAR.

    def comprobar_usuario(self, instancia):

        # Obtenemos el usuario escrito en el campo.
        usuario = self.campo_usuario.text

        # Obtenemos la contraseña escrita.
        password = self.campo_password.text

        # Convertimos la contraseña a SHA1.
        password_sha1 = hashlib.sha1(
            password.encode("utf-8")
        ).hexdigest()

        # Comprobamos primero si el usuario existe.
        if usuario in self.usuarios:

            # Obtenemos el SHA1 guardado para ese usuario.
            password_guardada = self.usuarios[usuario]

            # Comparamos el SHA1 escrito con el guardado.
            if password_sha1 == password_guardada:

                # Si coinciden, mostramos OK.
                self.resultado.text = "OK"

            else:

                # Si no coinciden, mostramos ERROR.
                self.resultado.text = "ERROR"

        else:

            # Si el usuario no existe, mostramos ERROR.
            self.resultado.text = "ERROR"


# INICIAMOS LA APLICACIÓN

# Creamos la aplicación y la ejecutamos.
LoginApp().run()