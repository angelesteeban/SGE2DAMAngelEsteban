# Actividad 08

# ORGANIZADOR DE ARCHIVOS

# Importamos os.
# Nos permite trabajar con carpetas y archivos.
import os

# Importamos shutil.
# Nos permite mover archivos de una carpeta a otra.
import shutil


# FUNCIÓN PARA ORGANIZAR LOS ARCHIVOS

def organizarArchivos(extensiones):

    # Obtenemos la carpeta actual.
    
    # "." significa la carpeta en la que estamos trabajando.
    carpeta_actual = "."


    # RECORRER LAS EXTENSIONES

    # Recorremos una por una las extensiones de la lista.
    
    # Por ejemplo:
    
    # ["png", "mp4", "doc"]
    
    # Primero extension será "png".
    # Después será "mp4".
    # Finalmente será "doc".
    for extension in extensiones:

        # Creamos el nombre de la carpeta.
        
        # Si extension = "png"
        # carpeta = "png"
        carpeta = extension


        # CREAR LA CARPETA

        # Comprobamos si la carpeta todavía no existe.
        if not os.path.exists(carpeta):

            # Creamos la carpeta.
            os.mkdir(carpeta)


        # RECORRER LOS ARCHIVOS DE LA CARPETA ACTUAL

        # os.listdir() devuelve todos los archivos y carpetas
        # que hay dentro de la carpeta actual.
        archivos = os.listdir(carpeta_actual)


        # Recorremos todos los elementos encontrados.
        for archivo in archivos:

            # Creamos la ruta completa del archivo.
            ruta_archivo = os.path.join(
                carpeta_actual,
                archivo
            )


            # COMPROBAR QUE SEA UN ARCHIVO

            # No queremos intentar mover carpetas.
            if os.path.isfile(ruta_archivo):

                # COMPROBAR LA EXTENSIÓN

                # Comprobamos si el archivo termina con
                # la extensión que estamos buscando.
                
                # Por ejemplo:
                
                # foto.png
                
                # termina en ".png".
                if archivo.lower().endswith(
                    "." + extension.lower()
                ):

                    # CREAR LA RUTA DE DESTINO

                    destino = os.path.join(
                        carpeta,
                        archivo
                    )


                    # MOVER EL ARCHIVO

                    shutil.move(
                        ruta_archivo,
                        destino
                    )


# LISTA DE EXTENSIONES

# Creamos una lista con las extensiones
# que queremos organizar.
extensiones = [
    "png",
    "mp4",
    "doc"
]


# EJECUTAR EL ORGANIZADOR

organizarArchivos(extensiones)


# Mostramos un mensaje cuando hemos terminado.
print("Archivos organizados correctamente.")