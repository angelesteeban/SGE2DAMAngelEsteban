# CLASE ESCOLA - ACTIVIDAD 06

# Importamos las herramientas de SQLAlchemy que necesitamos
# para crear las columnas de nuestra tabla.
from sqlalchemy import Column, Integer, String

# Importamos declarative_base().
# Nos permite crear clases que SQLAlchemy puede convertir
# en tablas de una base de datos.
from sqlalchemy.orm import declarative_base


# BASE DE SQLALCHEMY

# Creamos la clase Base.

# Las clases que queramos guardar en la base de datos
# heredarán de esta clase.
Base = declarative_base()


# CLASE ESCOLA2

class Escola2(Base):

    # Nombre de la tabla en SQLite.
    __tablename__ = "escoles2"

    # Identificador único de la escuela.
    # primary_key=True significa que es la clave primaria.
    id = Column(Integer, primary_key=True)

    # Nombre de la escuela.
    nombre = Column(String, nullable=False)

    # Localidad de la escuela.
    localidad = Column(String, nullable=False)

    # Nombre del responsable de la escuela.
    responsable = Column(String, nullable=False)


    # CONSTRUCTOR

    def __init__(self, nombre, localidad, responsable):

        self.nombre = nombre
        self.localidad = localidad
        self.responsable = responsable


    # MOSTRAR INFORMACIÓN

    def __str__(self):

        return (
            f"Escuela: {self.nombre} | "
            f"Localidad: {self.localidad} | "
            f"Responsable: {self.responsable}"
        )