# ACTIVIDAD 15 - FILTRO DEL PORTAPAPELES

import sys
import time
import pyperclip


# Comprobamos que se ha indicado el fichero de palabras
# prohibidas como parámetro.

if len(sys.argv) != 2:

    print("Uso: python UD00Act2.15AngelEsteban.py lista.txt")

else:

    # Guardamos el nombre del fichero.

    fichero = sys.argv[1]

    # Leemos el fichero de palabras prohibidas.

    palabras_prohibidas = []

    with open(fichero, "r", encoding="utf-8") as archivo:

        for linea in archivo:

            palabra = linea.strip()

            if palabra != "":
                palabras_prohibidas.append(palabra)

    # Mostramos las palabras que hemos cargado.

    print("Filtro iniciado.")
    print("Palabras prohibidas:")

    for palabra in palabras_prohibidas:
        print("-", palabra)

    print()
    print("Ahora copia cualquier texto.")
    print("Pulsa Ctrl+C en esta ventana para terminar.")
    print()

    # Guardamos el contenido actual del portapapeles.

    texto_anterior = pyperclip.paste()

    # El programa se queda funcionando continuamente.

    try:

        while True:

            # Miramos el contenido actual del portapapeles.
            texto = pyperclip.paste()

            # Si no ha cambiado, esperamos medio segundo.
            if texto == texto_anterior:
                time.sleep(0.5)
                continue

            # Guardamos el nuevo contenido.
            texto_anterior = texto

            # Empezamos a filtrar el texto.

            texto_filtrado = texto

            # Recorremos todas las palabras prohibidas.
            for palabra in palabras_prohibidas:

                # Versión en minúsculas para comparar
                # sin distinguir mayúsculas/minúsculas.
                palabra_minusculas = palabra.lower()

                resultado = ""
                posicion = 0

                # Recorremos el texto.
                while posicion < len(texto_filtrado):

                    # Extraemos un trozo del mismo tamaño
                    # que la palabra prohibida.
                    trozo = texto_filtrado[
                        posicion:posicion + len(palabra)
                    ]

                    # Comparamos sin distinguir mayúsculas
                    # y minúsculas.
                    if trozo.lower() == palabra_minusculas:

                        # Sustituimos la palabra por asteriscos.
                        resultado += "*" * len(palabra)

                        # Saltamos los caracteres de la palabra.
                        posicion += len(palabra)

                    else:

                        # Copiamos el carácter normal.
                        resultado += texto_filtrado[posicion]

                        posicion += 1

                # Actualizamos el texto filtrado.
                texto_filtrado = resultado

            # Si hemos encontrado alguna palabra prohibida,
            # copiamos el texto modificado al portapapeles.

            if texto_filtrado != texto:

                pyperclip.copy(texto_filtrado)

                print("Texto filtrado:")
                print(texto_filtrado)
                print()

            else:

                print("Texto copiado sin palabras prohibidas.")
                print()

    except KeyboardInterrupt:

        print()
        print("Filtro detenido.")