# CLASE ESCOLA

class Escola:

    # Constructor de la escuela.
    def __init__(self, nombre, localidad, responsable):

        # Información básica de la escuela.
        self.nombre = nombre
        self.localidad = localidad
        self.responsable = responsable

        # Diccionario donde guardaremos los profesores.
        
        # La clave será el nombre del profesor.
        self.profesores = {}

        # Diccionario donde guardaremos los grupos.
        
        # Cada grupo tendrá una lista de alumnos.
        self.grupos = {}


    # PROFESORES

    # AÑADIR PROFESOR

    def añadirProfesor(self, profesor):

        # Comprobamos si el profesor ya existe.
        if profesor.nombre in self.profesores:

            print("El profesor ya existe.")

        else:

            # Guardamos el profesor en el diccionario.
            self.profesores[profesor.nombre] = profesor

            print("Profesor añadido correctamente.")


    # ELIMINAR PROFESOR

    def eliminarProfesor(self, nombre):

        # Comprobamos si el profesor existe.
        if nombre in self.profesores:

            # Lo eliminamos.
            del self.profesores[nombre]

            print("Profesor eliminado.")

        else:

            print("El profesor no existe.")


    # MOSTRAR PROFESORES

    def mostrarProfesores(self):

        print("\n--- PROFESORES ---")

        # Recorremos todos los profesores.
        for profesor in self.profesores.values():

            print(profesor.mostrar())


    # GRUPOS

    # AÑADIR GRUPO

    def añadirGrupo(self, nombreGrupo):

        # Comprobamos si el grupo ya existe.
        if nombreGrupo in self.grupos:

            print("El grupo ya existe.")

        else:

            # Creamos una lista vacía para los alumnos.
            self.grupos[nombreGrupo] = []

            print("Grupo añadido correctamente.")


    # AÑADIR ALUMNO A UN GRUPO

    def añadirAlumno(self, nombreGrupo, alumno):

        # Comprobamos que el grupo exista.
        if nombreGrupo not in self.grupos:

            print("El grupo no existe.")
            return

        # Comprobamos si el alumno ya está en algún grupo.
        for grupo in self.grupos.values():

            for alumnoExistente in grupo:

                if alumnoExistente.nombre == alumno.nombre:

                    print("El alumno ya está en la escuela.")
                    return

        # Añadimos el alumno al grupo.
        self.grupos[nombreGrupo].append(alumno)

        print("Alumno añadido correctamente.")


    # ELIMINAR ALUMNO

    def eliminarAlumno(self, nombreGrupo, nombreAlumno):

        # Comprobamos que el grupo exista.
        if nombreGrupo not in self.grupos:

            print("El grupo no existe.")
            return

        # Recorremos los alumnos del grupo.
        for alumno in self.grupos[nombreGrupo]:

            # Buscamos el alumno por su nombre.
            if alumno.nombre == nombreAlumno:

                # Lo eliminamos.
                self.grupos[nombreGrupo].remove(alumno)

                print("Alumno eliminado.")
                return

        print("El alumno no existe.")


    # MOSTRAR ALUMNOS

    def mostrarAlumnos(self):

        print("\n--- ALUMNOS ---")

        # Recorremos todos los grupos.
        for nombreGrupo, alumnos in self.grupos.items():

            print("\nGrupo:", nombreGrupo)

            # Mostramos los alumnos del grupo.
            for alumno in alumnos:

                print(alumno.mostrar())


    # MOSTRAR INFORMACIÓN DE LA ESCUELA

    def mostrarInformacion(self):

        print("ESCUELA:", self.nombre)
        print("LOCALIDAD:", self.localidad)
        print("RESPONSABLE:", self.responsable)

        self.mostrarProfesores()

        self.mostrarAlumnos()