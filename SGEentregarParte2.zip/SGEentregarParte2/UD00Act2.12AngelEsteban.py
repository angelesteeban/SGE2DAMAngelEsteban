# ACTIVIDAD 12 - RECONOCIMIENTO DE TEXTO EN IMÁGENES

# Importamos OpenCV.
# Lo utilizaremos para cargar y manipular la imagen.
import cv2

# Importamos pytesseract.
# Esta librería permite utilizar Tesseract OCR desde Python.
import pytesseract


# IMAGEN QUE QUEREMOS ANALIZAR

# Indicamos el nombre de la imagen que queremos leer.

# La imagen debe estar en la misma carpeta que este programa.
nombre_imagen = "imagen.png"


# CARGAMOS LA IMAGEN

# cv2.imread() carga la imagen desde el archivo.
imagen = cv2.imread(nombre_imagen)


# Comprobamos que la imagen se haya cargado correctamente.
if imagen is None:

    # Si no se ha encontrado la imagen, mostramos un mensaje.
    print("ERROR: No se ha podido cargar la imagen.")

else:

    # CONVERTIMOS LA IMAGEN DE BGR A RGB

    # OpenCV carga las imágenes utilizando el orden de colores
    # BGR (Blue, Green, Red).
    
    # Tesseract trabaja con imágenes en formato RGB
    # (Red, Green, Blue).
    
    # Por eso hacemos esta conversión.
    imagen_rgb = cv2.cvtColor(
        imagen,
        cv2.COLOR_BGR2RGB
    )


    # RECONOCIMIENTO DEL TEXTO

    # image_to_string() analiza la imagen mediante OCR
    # y devuelve el texto que ha conseguido reconocer.
    texto = pytesseract.image_to_string(
        imagen_rgb
    )

    # MOSTRAMOS EL RESULTADO

    # Mostramos en la terminal el texto reconocido.
    print("Texto reconocido:")
    print("-----------------")
    print(texto)
