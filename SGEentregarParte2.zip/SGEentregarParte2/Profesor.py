# CLASE PROFESOR

class Profesor:

    # Constructor de la clase.
    # Se ejecuta cuando creamos un profesor.
    def __init__(self, nombre, tipo):

        # Guardamos el nombre del profesor.
        self.nombre = nombre

        # Guardamos el tipo de profesor.
        # Puede ser:
        # ciencias
        # letras
        # mixto
        self.tipo = tipo


    # MÉTODO PARA MOSTRAR EL PROFESOR

    def mostrar(self):

        # Devolvemos un texto con la información
        # del profesor.
        return self.nombre + " - " + self.tipo