# Ángel Esteban Parra

# Actividad 01

# 1. FUNCIÓN LAMBDA

# Una función lambda es una función pequeña y sencilla
# que se puede escribir en una sola línea.

# En este ejemplo, creamos una función que recibe un número
# y devuelve su cuadrado.

cuadrado = lambda x: x ** 2

# Llamamos a la función lambda con el número 5.
resultado = cuadrado(5)

# Mostramos el resultado por pantalla.
print("El cuadrado de 5 es:", resultado)


# 2. CONVERTIR UNA CADENA DE TEXTO EN UNA LISTA DE ENTEROS

# Pedimos al usuario que introduzca varios números
# separados por espacios.

# Por ejemplo:
# 2 5 8 12 15 20

texto = input("Introduce varios números separados por espacios: ")

# La función split() separa la cadena cada vez que encuentra
# un espacio.

# Si el usuario escribe:
# "2 5 8 12"

# split() devuelve:
# ["2", "5", "8", "12"]

numeros_texto = texto.split()


# Ahora utilizamos map() junto con int().

# map(int, numeros_texto) convierte cada elemento de la lista
# de texto en un número entero.

# Por ejemplo:
# ["2", "5", "8"]  ->  [2, 5, 8]

# Como map() devuelve un objeto iterable, utilizamos list()
# para convertirlo en una lista.

numeros = list(map(int, numeros_texto))

# Mostramos la lista de números enteros.
print("Lista de números:", numeros)


# 3. ELIMINAR LOS NÚMEROS MENORES QUE 10

# Utilizamos filter() para quedarnos solamente con los
# números que cumplen una determinada condición.

# La función lambda comprueba si cada número es mayor o igual
# que 10.

# Si el número es >= 10, filter() lo conserva.
# Si es menor que 10, lo elimina.

numeros_mayores_igual_10 = list(
    filter(lambda x: x >= 10, numeros)
)

# Mostramos la lista después de aplicar filter().
print("Números mayores o iguales que 10:",
      numeros_mayores_igual_10)


# 4. MULTIPLICAR TODOS LOS ELEMENTOS CON reduce()

# Para utilizar reduce(), tenemos que importarlo desde
# el módulo functools.

from functools import reduce


# reduce() aplica una función a los elementos de una lista
# acumulando el resultado.

# En este caso:

# [10, 12, 20]

# Primero:
# 10 * 12 = 120

# Después:
# 120 * 20 = 2400

# Por tanto, el resultado final es 2400.

resultado_multiplicacion = reduce(
    lambda x, y: x * y,
    numeros_mayores_igual_10
)

# Mostramos el resultado final.
print("Multiplicación de los elementos:", resultado_multiplicacion)

# ---------------------------------------------------------------------------------------------------------------------------------------

# Actividad 02

# COMPROBADOR DE SUDOKU

# Esta función recibe como parámetro el Sudoku.
# El Sudoku estará almacenado como una lista de listas.

# La función devolverá:
# True si el Sudoku es correcto
# False si el Sudoku es incorrecto

def esSudokuCorrecto(miArrayBi):

    # 1. COMPROBAR LAS FILAS

    # Recorremos las 9 filas del Sudoku.
    for fila in miArrayBi:

        # Convertimos la fila en un conjunto (set).
        # Un set no permite elementos repetidos.
        
        # Si una fila es:
        # [5, 3, 4, 6, 7, 8, 9, 1, 2]
        
        # tendrá 9 elementos diferentes.
        
        # Si hay un número repetido, tendrá menos de 9.
        if len(set(fila)) != 9:
            return False

    # 2. COMPROBAR LAS COLUMNAS

    # Recorremos las 9 columnas.
    for columna in range(9):

        # Creamos una lista vacía para guardar
        # los números de la columna.
        numeros_columna = []

        # Recorremos las 9 filas.
        for fila in range(9):

            # Añadimos a la lista el número que está
            # en la columna que estamos comprobando.
            numeros_columna.append(miArrayBi[fila][columna])

        # Comprobamos que no haya números repetidos.
        if len(set(numeros_columna)) != 9:
            return False


    # 3. COMPROBAR LOS CUADRADOS 3x3

    # Un Sudoku tiene 9 cuadrados de 3x3.
    
    # Las variables filaInicio y columnaInicio indican
    # dónde empieza cada cuadrado.

    for filaInicio in range(0, 9, 3):

        for columnaInicio in range(0, 9, 3):

            # Lista donde guardaremos los números
            # del cuadrado 3x3.
            numeros_cuadrado = []

            # Recorremos las 3 filas del cuadrado.
            for fila in range(filaInicio, filaInicio + 3):

                # Recorremos las 3 columnas del cuadrado.
                for columna in range(
                    columnaInicio,
                    columnaInicio + 3
                ):

                    # Guardamos el número.
                    numeros_cuadrado.append(
                        miArrayBi[fila][columna]
                    )

            # Comprobamos que los 9 números sean diferentes.
            if len(set(numeros_cuadrado)) != 9:
                return False


    # 4. SI ESTÁ BIEN

    # Si hemos llegado hasta aquí significa que:
    
    # Las filas son correctas.
    # Las columnas son correctas.
    # Los cuadrados 3x3 son correctos.
    
    # Por tanto, el Sudoku es correcto.

    return True


# LEER EL ARCHIVO Sudoku.in

# Abrimos el archivo "Sudoku.in" en modo lectura ("r").
with open("Sudoku.in", "r") as archivo:

    # Creamos una lista vacía donde guardaremos
    # todo el Sudoku.
    miArrayBi = []

    # Leemos el archivo línea por línea.
    for linea in archivo:

        # Quitamos los espacios y el salto de línea
        # que hay al final de cada línea.
        linea = linea.strip()

        # Separamos los números utilizando el espacio.
        
        # Por ejemplo:
        # "5 3 4 6 7 8 9 1 2"
        
        # se convierte en:
        # ["5", "3", "4", "6", "7", "8", "9", "1", "2"]
        numeros = linea.split()

        # Convertimos cada número de texto a entero.
        numeros = list(map(int, numeros))

        # Añadimos la fila al Sudoku.
        miArrayBi.append(numeros)


# COMPROBAR EL SUDOKU

# Llamamos a nuestra función.
resultado = esSudokuCorrecto(miArrayBi)


# MOSTRAR EL RESULTADO

# Si la función devuelve True
if resultado:

    # El Sudoku es correcto.
    print("Correcto")

else:

    # El Sudoku es incorrecto.
    print("Incorrecto")

# ----------------------------------------------------------------------------------------------------------------------------------------

# Actividad 03

# FUNCIÓN PARA CONTAR LOS PATRONES

def numeroPatrones(text):
    """
    Esta función recibe una cadena de texto y devuelve
    el número total de patrones encontrados.

    Los patrones que tenemos que buscar son:
        "00"
        "101"
        "ABC"
        "HO"

    Los patrones pueden aparecer solapados.
    """

    # Guardamos los patrones que tenemos que buscar
    # en una lista.
    patrones = ["00", "101", "ABC", "HO"]

    # Esta variable almacenará el número total
    # de patrones encontrados.
    contador = 0

    # RECORRER TODOS LOS PATRONES

    # Recorremos uno a uno los patrones de la lista.
    for patron in patrones:

        # Guardamos la longitud del patrón.
        
        # Por ejemplo:
        # "00"  -> 2
        # "101" -> 3
        # "ABC" -> 3
        # "HO"  -> 2
        longitud = len(patron)

        # BUSCAR EL PATRÓN EN EL TEXTO

        # Recorremos todas las posiciones posibles
        # del texto.
        
        # Utilizamos len(text) - longitud + 1 porque
        # necesitamos asegurarnos de que quede espacio
        # suficiente para que quepa el patrón.
        for i in range(len(text) - longitud + 1):

            # Extraemos del texto una parte que tenga
            # exactamente la misma longitud que el patrón.
            
            # Por ejemplo, si buscamos "00" y el texto es
            # "000", comprobamos:
            
            # posición 0 -> "00"
            # posición 1 -> "00"
            
            # Por eso encontramos 2 coincidencias.
            trozo = text[i:i + longitud]

            # Comprobamos si el trozo es igual al patrón.
            if trozo == patron:

                # Si coincide, aumentamos el contador
                # en 1.
                contador += 1

    # Cuando terminamos de comprobar todos los patrones,
    # devolvemos el número total de coincidencias.
    return contador


# PEDIR UNA CADENA AL USUARIO

# input() permite al usuario introducir una cadena
# de texto por teclado.
texto = input("Introduce una cadena de texto: ")


# LLAMAR A LA FUNCIÓN

# Llamamos a numeroPatrones() y le pasamos la cadena
# introducida por el usuario.
resultado = numeroPatrones(texto)


# MOSTRAR EL RESULTADO

# Mostramos por pantalla el número de patrones encontrados.
print("Número de patrones:", resultado)

# ---------------------------------------------------------------------------------------------------------------------------------------

# Actividad 04

# FUNCIÓN QUE CUENTA LAS MINAS ADYACENTES

def contandoMinas(miCampo):

    # Obtenemos el número de filas del campo.
    filas = len(miCampo)

    # Creamos una matriz nueva para guardar el resultado.
    # Al principio tendrá todos los valores a 0.
    resultado = []

    for i in range(filas):

        # Creamos una fila con tantos ceros como columnas
        # tenga la fila original.
        fila = [0] * len(miCampo[i])

        # Añadimos la fila a la matriz resultado.
        resultado.append(fila)

    # RECORRER TODAS LAS POSICIONES DEL CAMPO

    for fila in range(filas):

        # Número de columnas de la fila actual.
        columnas = len(miCampo[fila])

        for columna in range(columnas):

            # Si la posición actual es -1, significa que
            # hay una mina.
            
            # En ese caso dejamos -1 en el resultado.
            if miCampo[fila][columna] == -1:

                resultado[fila][columna] = -1

            else:

                # Contador de minas que hay alrededor
                # de la posición actual.
                contador = 0


                # COMPROBAR LAS 8 POSICIONES ADYACENTES

                # Recorremos las filas que están alrededor.
                for df in range(-1, 2):

                    # Recorremos las columnas que están
                    # alrededor.
                    for dc in range(-1, 2):

                        # Calculamos la posición del vecino.
                        nuevaFila = fila + df
                        nuevaColumna = columna + dc


                        # Comprobamos que la posición esté
                        # dentro de los límites del campo.
                        if (0 <= nuevaFila < filas and
                            0 <= nuevaColumna < len(miCampo[nuevaFila])):

                            # Comprobamos que no estemos
                            # comprobando la propia casilla.
                            if not (df == 0 and dc == 0):

                                # Si encontramos una mina,
                                # aumentamos el contador.
                                
                                # Según el ejemplo del ejercicio,
                                # tanto -1 como 1 representan
                                # una mina.
                                if (miCampo[nuevaFila][nuevaColumna] == -1 or
                                    miCampo[nuevaFila][nuevaColumna] == 1):

                                    contador += 1


                # Guardamos el número de minas encontradas
                # alrededor de la posición.
                resultado[fila][columna] = contador


    # Devolvemos la matriz con el resultado.
    return resultado


# LEER EL CAMPO POR TECLADO

# Pedimos al usuario el número de filas.
numeroFilas = int(input("Número de filas: "))


# Creamos una lista vacía para guardar el campo.
miCampo = []


# Leemos cada fila.
for i in range(numeroFilas):

    # Pedimos una fila de números.
    linea = input("Introduce la fila: ")

    # Separamos los números utilizando los espacios.
    numeros = linea.split()

    # Convertimos los números de texto a números enteros.
    numeros = list(map(int, numeros))

    # Guardamos la fila en el campo.
    miCampo.append(numeros)


# CALCULAR EL RESULTADO

# Llamamos a la función contandoMinas().
resultado = contandoMinas(miCampo)


# MOSTRAR EL RESULTADO

print("Resultado:")

# Recorremos todas las filas del resultado.
for fila in resultado:

    # Convertimos los números a texto y los juntamos
    # utilizando espacios.
    print(" ".join(map(str, fila)))

# ---------------------------------------------------------------------------------------------------------------------------------------

# Actividad 05

# IMPORTAMOS LAS CLASES

from Profesor import Profesor
from Alumno import Alumno
from Escola import Escola


# CREAR PROFESORES

# Creamos el primer profesor.
profesor1 = Profesor(
    "Juan",
    "ciencias"
)

# Creamos el segundo profesor.
profesor2 = Profesor(
    "María",
    "letras"
)

# Creamos el tercer profesor.
profesor3 = Profesor(
    "Pedro",
    "mixto"
)


# CREAR LA ESCUELA

escuela = Escola(
    "IES Mediterráneo",
    "Valencia",
    "Laura"
)


# AÑADIR PROFESORES A LA ESCUELA

escuela.añadirProfesor(profesor1)

escuela.añadirProfesor(profesor2)

escuela.añadirProfesor(profesor3)


# CREAR GRUPOS

escuela.añadirGrupo("1ESO-A")

escuela.añadirGrupo("2ESO-B")


# CREAR ALUMNOS

alumno1 = Alumno(
    "Carlos",
    "1ESO",
    profesor1
)

alumno2 = Alumno(
    "Ana",
    "1ESO",
    profesor2
)

alumno3 = Alumno(
    "Luis",
    "2ESO",
    profesor3
)


# AÑADIR ALUMNOS A LOS GRUPOS

escuela.añadirAlumno(
    "1ESO-A",
    alumno1
)

escuela.añadirAlumno(
    "1ESO-A",
    alumno2
)

escuela.añadirAlumno(
    "2ESO-B",
    alumno3
)


# MOSTRAR TODA LA INFORMACIÓN

escuela.mostrarInformacion()


# PROBAR LA ELIMINACIÓN DE UN ALUMNO

print("\nEliminando a Carlos...")

escuela.eliminarAlumno(
    "1ESO-A",
    "Carlos"
)


# MOSTRAR DE NUEVO LOS ALUMNOS

escuela.mostrarAlumnos()

# -----------------------------------------------------------------------------------------------------------------------------------------

# Actividad 06

# Importamos create_engine().
# Sirve para conectar nuestro programa con SQLite.
from sqlalchemy import create_engine

# sessionmaker() permite crear sesiones
# para trabajar con la base de datos.
from sqlalchemy.orm import sessionmaker


# IMPORTAR NUESTRAS CLASES

from Escola2 import Base, Escola2
from Profesor2 import Profesor2
from Alumno2 import Alumno2


# CREAR LA BASE DE DATOS

# Creamos una base de datos SQLite llamada:

# escuela2.db

# Si el archivo no existe, SQLite lo creará.
engine = create_engine("sqlite:///escuela2.db")


# CREAR LAS TABLAS

# SQLAlchemy utiliza nuestras clases para crear
# las tablas correspondientes en la base de datos.
Base.metadata.create_all(engine)


# CREAR UNA SESIÓN

# Creamos una clase para poder trabajar
# con la base de datos.
Session = sessionmaker(bind=engine)

# Creamos una sesión.
session = Session()


# CREAR UNA ESCUELA

escuela = Escola2(
    "IES Mediterráneo",
    "Valencia",
    "Laura"
)


# Añadimos la escuela a la sesión.
session.add(escuela)

# Guardamos los cambios.
session.commit()


# CREAR PROFESORES

profesor1 = Profesor2(
    "Juan",
    "ciencias",
    escuela
)

profesor2 = Profesor2(
    "María",
    "letras",
    escuela
)


# Añadimos los profesores.
session.add(profesor1)
session.add(profesor2)

# Guardamos los cambios.
session.commit()


# CREAR ALUMNOS

alumno1 = Alumno2(
    "Carlos",
    "1ESO",
    "A",
    escuela,
    profesor1
)

alumno2 = Alumno2(
    "Ana",
    "1ESO",
    "A",
    escuela,
    profesor2
)

alumno3 = Alumno2(
    "Luis",
    "2ESO",
    "B",
    escuela,
    profesor1
)


# GUARDAR LOS ALUMNOS

# Añadimos los tres alumnos a la sesión.
session.add(alumno1)
session.add(alumno2)
session.add(alumno3)

# Confirmamos los cambios.

# En este momento los alumnos quedan guardados
# físicamente en la base de datos.
session.commit()


print("Alumnos guardados correctamente.")


# RECUPERAR LOS ALUMNOS

# Consultamos todos los alumnos almacenados
# en la tabla alumnos2.
alumnos = session.query(Alumno2).all()


# MOSTRAR LOS ALUMNOS

print("\n--- ALUMNOS GUARDADOS EN LA BASE DE DATOS ---")

# Recorremos la lista de alumnos.
for alumno in alumnos:

    print(alumno)


# CERRAR LA SESIÓN

session.close()

print("\nPrograma terminado.")

# ---------------------------------------------------------------------------------------------------------------------------------------

# Actividad 07

# Programa que:
# - Lee números desde un fichero de entrada.
# - Comprueba cuáles son palíndromos.
# - Comprueba cuáles son primos.
# - Escribe los resultados en un fichero de salida.

# Además, las funciones esPalindromo() y esPrimo()
# tienen pruebas unitarias mediante doctest.


# IMPORTACIONES

# sys nos permite acceder a los parámetros
# que escribimos al ejecutar el programa.
import sys

# math nos permite utilizar sqrt(), es decir,
# la raíz cuadrada de un número.
import math

# doctest permite ejecutar los ejemplos que tenemos
# escritos dentro de las funciones como pruebas.
import doctest


# FUNCIÓN ES PALÍNDROMO

def esPalindromo(numero):
    """
    Comprueba si un número es palíndromo.

    Un número palíndromo es aquel que se lee igual
    de izquierda a derecha que de derecha a izquierda.

    Ejemplos:

    >>> esPalindromo(5)
    True

    >>> esPalindromo(11)
    True

    >>> esPalindromo(22)
    True

    >>> esPalindromo(13)
    False

    >>> esPalindromo(123)
    False
    """

    # Convertimos el número a texto.
    texto = str(numero)

    # [::-1] sirve para invertir una cadena.
    texto_invertido = texto[::-1]

    # Comparamos el número original con el invertido.
    return texto == texto_invertido


# FUNCIÓN ES PRIMO

def esPrimo(numero):
    """
    Comprueba si un número es primo.

    Un número primo solamente puede dividirse
    exactamente entre 1 y entre él mismo.

    Ejemplos:

    >>> esPrimo(2)
    True

    >>> esPrimo(5)
    True

    >>> esPrimo(11)
    True

    >>> esPrimo(13)
    True

    >>> esPrimo(4)
    False

    >>> esPrimo(15)
    False

    >>> esPrimo(1)
    False
    """

    # Los números menores que 2 no son primos.
    if numero < 2:
        return False

    # El 2 es primo.
    if numero == 2:
        return True

    # Los números pares mayores que 2 no son primos.
    if numero % 2 == 0:
        return False

    # Comprobamos posibles divisores desde 3
    # hasta la raíz cuadrada del número.
    limite = int(math.sqrt(numero)) + 1

    for divisor in range(3, limite, 2):

        # Si la división es exacta,
        # el número no es primo.
        if numero % divisor == 0:
            return False

    # Si no hemos encontrado ningún divisor,
    # el número es primo.
    return True


# FUNCIÓN PRINCIPAL

def main():
    """
    Función principal del programa.

    Recibe dos parámetros desde la consola:

        1. Fichero de entrada.
        2. Fichero de salida.
    """

    # COMPROBAR LOS PARÁMETROS

    # sys.argv contiene los parámetros escritos
    # al ejecutar el programa.
    
    # sys.argv[0] -> nombre del programa
    # sys.argv[1] -> fichero de entrada
    # sys.argv[2] -> fichero de salida
    
    # Por tanto necesitamos 3 elementos.
    if len(sys.argv) != 3:

        print(
            "Uso: python UD00Act2AngelEsteban.py "
            "ficheroEntrada.txt ficheroSalida.txt"
        )

        return


    # GUARDAR LOS NOMBRES DE LOS FICHEROS

    # Guardamos el nombre del fichero de entrada.
    fichero_entrada = sys.argv[1]

    # Guardamos el nombre del fichero de salida.
    fichero_salida = sys.argv[2]


    # LEER EL FICHERO DE ENTRADA

    # Creamos una lista vacía donde guardaremos
    # todos los números.
    numeros = []

    # Abrimos el fichero de entrada en modo lectura.
    with open(fichero_entrada, "r", encoding="utf-8") as archivo:

        # Recorremos todas las líneas del fichero.
        for linea in archivo:

            # Quitamos espacios y salto de línea.
            linea = linea.strip()

            # Si la línea no está vacía
            if linea != "":

                # Convertimos el texto a número entero.
                numero = int(linea)

                # Añadimos el número a la lista.
                numeros.append(numero)


    # CONTADORES

    # Contador de números palíndromos.
    cantidad_palindromos = 0

    # Contador de números primos.
    cantidad_primos = 0

    # Lista para guardar los números que son
    # simultáneamente primos y palíndromos.
    primos_y_palindromos = []


    # COMPROBAR LOS NÚMEROS

    # Recorremos todos los números leídos.
    for numero in numeros:

        # Comprobamos si es palíndromo.
        palindromo = esPalindromo(numero)

        # Comprobamos si es primo.
        primo = esPrimo(numero)


        # Si es palíndromo
        if palindromo:

            # Aumentamos el contador.
            cantidad_palindromos += 1


        # Si es primo
        if primo:

            # Aumentamos el contador.
            cantidad_primos += 1


        # Si es primo Y palíndromo
        if primo and palindromo:

            # Lo añadimos a la lista.
            primos_y_palindromos.append(numero)


    # CREAR EL FICHERO DE SALIDA

    # Abrimos el fichero de salida en modo escritura.
    with open(fichero_salida, "w", encoding="utf-8") as archivo:

        # Primera línea:
        # cantidad de números palíndromos.
        archivo.write(
            f"Hay {cantidad_palindromos} números palíndromos.\n"
        )

        # Segunda línea:
        # cantidad de números primos.
        archivo.write(
            f"Hay {cantidad_primos} números primos.\n"
        )

        # NÚMEROS QUE SON PRIMOS Y PALÍNDROMOS

        # Recorremos la lista.
        for numero in primos_y_palindromos:

            # Escribimos un número por línea.
            archivo.write(f"{numero}\n")


# EJECUCIÓN DEL PROGRAMA

if __name__ == "__main__":

    # Si ejecutamos:
    # python UD00Act2AngelEsteban.py entrada.txt salida.txt
    # se ejecutará el programa.

    main()

# ------------------------------------------------------------------------------------------------------------------------------------

# Actividad 09

# GENERAR CÓDIGOS DE BARRAS

import sys
import csv
from barcode import EAN13
from barcode.writer import ImageWriter


# Comprobamos que se haya pasado un archivo CSV
# como parámetro al ejecutar el programa.
if len(sys.argv) != 2:

    # Si no se ha pasado exactamente un archivo,
    # mostramos cómo utilizar el programa.
    print("Uso: python UD00Act2AngelEsteban.py alumnos.csv")

else:

    # Guardamos el nombre del archivo CSV.
    fichero_csv = sys.argv[1]

    # Abrimos el archivo CSV.
    with open(fichero_csv, "r", encoding="utf-8", newline="") as archivo:

        # Creamos el lector del CSV.
        lector = csv.reader(archivo)

        # Recorremos todos los alumnos del archivo.
        for fila in lector:

            # Si encontramos una línea vacía, la ignoramos.
            if not fila:
                continue

            # Primera columna: nombre del alumno.
            nombre = fila[0].strip()

            # Segunda columna: ID del alumno.
            identificador = fila[1].strip()

            # EAN-13 necesita 12 números.
            # Rellenamos el ID con ceros por la izquierda.
            codigo = identificador.zfill(12)

            # Creamos el código de barras EAN-13.
            codigo_barras = EAN13(
                codigo,
                writer=ImageWriter()
            )

            # Guardamos el código de barras.
            # Se creará automáticamente como PNG.
            # Por ejemplo: "Alumne 01.png"
            codigo_barras.save(nombre)

    # Avisamos de que hemos terminado.
    print("Códigos de barras generados correctamente.")
# --------------------------------------------------------------------------------------------------------------------------------------

# Actividad 10


# Importamos os para poder trabajar con carpetas y archivos.
import os

# Importamos cv2 para poder leer las imágenes PNG.
import cv2

# Importamos decode de pyzbar para detectar y leer
# los códigos de barras que hay dentro de las imágenes.
from pyzbar.pyzbar import decode


# CARPETA DONDE ESTÁN LOS PNG

# "." significa la carpeta actual.
# Es decir, la misma carpeta donde ejecutamos el programa.
carpeta = "."


# RECORREMOS TODOS LOS ARCHIVOS DE LA CARPETA

# os.listdir() nos devuelve todos los archivos y carpetas
# que existen dentro de la carpeta indicada.
for archivo in os.listdir(carpeta):

    # Comprobamos si el archivo termina en ".png".
    if archivo.lower().endswith(".png"):

        # Creamos la ruta completa del archivo.
        ruta = os.path.join(carpeta, archivo)

        # Leemos la imagen PNG utilizando OpenCV.
        imagen = cv2.imread(ruta)

        # Intentamos detectar los códigos de barras
        # que hay dentro de la imagen.
        codigos = decode(imagen)

        # Comprobamos si no se ha encontrado ningún código.
        if not codigos:

            print("No se ha encontrado ningún código en:", archivo)

        else:

            # Recorremos los códigos encontrados.
            for codigo_barras in codigos:

                # Extraemos los datos que contiene el código.
                # barcode.data devuelve los datos como bytes.
                datos = codigo_barras.data.decode("utf-8")

                # El nombre del alumno es el nombre del PNG
                # sin la extensión ".png".
                nombre_alumno = os.path.splitext(archivo)[0]

                # Mostramos el nombre del alumno y su ID.
                print("Alumno:", nombre_alumno, "- ID:", datos)

# ---------------------------------------------------------------------------------------------------------------------------------------

# Actividad 13

# Importamos la biblioteca requests.
# Nos permite hacer peticiones HTTP a una API.
import requests


# PEDIMOS LA ESPECIE AL USUARIO

# Pedimos al usuario que escriba una especie.
especie = input("Introduce una especie (Human, Alien, Robot): ")


# URL DE LA API

# Esta es la dirección de la API de Rick y Morty.
url = "https://rickandmortyapi.com/api/character"


# HACEMOS LA PETICIÓN A LA API

# Realizamos una petición GET.

# El parámetro "species" permite filtrar los personajes
# según la especie que ha introducido el usuario.
respuesta = requests.get(
    url,
    params={"species": especie}
)


# COMPROBAMOS SI LA PETICIÓN HA FUNCIONADO

# Si la API responde con código 200, la petición
# se ha realizado correctamente.
if respuesta.status_code == 200:

    # Convertimos la respuesta JSON en un diccionario
    # de Python.
    datos = respuesta.json()

    # Mostramos un título.
    print("\nPersonajes de la especie:", especie)
    print("----------------------------------------")

    # Recorremos la lista de personajes.
    for personaje in datos["results"]:

        # Mostramos solamente el nombre del personaje.
        print(personaje["name"])

else:

    # Si la API no encuentra personajes de esa especie,
    # mostramos un mensaje de error.
    print("No se han encontrado personajes de esa especie.")

# --------------------------------------------------------------------------------------------------------------------------------------

# Actividad 14

def es_segura(tablero, fila, columna):
    """
    Comprueba si podemos colocar una reina en la posición
    indicada sin que ataque a ninguna reina anterior.
    """

    # Recorremos las filas anteriores.
    for fila_anterior in range(fila):

        # Columna donde está colocada la reina anterior.
        columna_anterior = tablero[fila_anterior]

        # Comprobamos si están en la misma columna.
        if columna_anterior == columna:
            return False

        # Comprobamos si están en la misma diagonal.
        if abs(columna_anterior - columna) == abs(fila_anterior - fila):
            return False

    # Si no hay ningún conflicto, la posición es válida.
    return True


def contar_soluciones(tablero, fila, n):
    """
    Coloca las reinas fila por fila y devuelve
    el número total de soluciones encontradas.
    """

    # Si hemos colocado todas las reinas,
    # hemos encontrado una solución.
    if fila == n:
        return 1

    # Empezamos con 0 soluciones.
    soluciones = 0

    # Probamos todas las columnas de esta fila.
    for columna in range(n):

        # Comprobamos si podemos colocar una reina aquí.
        if es_segura(tablero, fila, columna):

            # Colocamos la reina.
            tablero[fila] = columna

            # Intentamos colocar la siguiente reina.
            soluciones += contar_soluciones(tablero, fila + 1, n)

            # Volvemos atrás para probar otra posición.
            tablero[fila] = -1

    # Devolvemos el número de soluciones encontradas.
    return soluciones


# Pedimos el tamaño del tablero.
n = int(input("Introduce el tamaño N del tablero (4-10): "))


# Comprobamos que N está dentro del rango permitido.
if n < 4 or n > 10:
    print("ERROR: N debe estar entre 4 y 10.")

else:
    # Creamos el tablero.
    
    # Cada posición representa una fila.
    # El valor indica en qué columna está la reina.
    
    # Por ejemplo:
    # [1, 3, 0, 2]
    
    # significa que:
    # fila 0 -> columna 1
    # fila 1 -> columna 3
    # fila 2 -> columna 0
    # fila 3 -> columna 2
    tablero = [-1] * n

    # Calculamos las soluciones.
    total = contar_soluciones(tablero, 0, n)

    # Mostramos el resultado.
    print("Número total de soluciones:", total)