# CLASE ALUMNO

class Alumno:

    # Constructor de la clase.
    def __init__(self, nombre, curso, profesor):

        # Guardamos el nombre del alumno.
        self.nombre = nombre

        # Guardamos el curso.
        self.curso = curso

        # Guardamos el profesor responsable.
        self.profesor = profesor


    # MÉTODO PARA MOSTRAR EL ALUMNO

    def mostrar(self):

        # Devolvemos la información del alumno.
        return (
            self.nombre
            + " - Curso: "
            + self.curso
            + " - Profesor: "
            + self.profesor.nombre
        )