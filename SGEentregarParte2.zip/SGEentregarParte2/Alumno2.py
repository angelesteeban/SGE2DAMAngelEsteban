# CLASE ALUMNO - ACTIVIDAD 06

# Importamos las herramientas de SQLAlchemy.
from sqlalchemy import Column, Integer, String, ForeignKey

# relationship() permite relacionar unas clases
# con otras.
from sqlalchemy.orm import relationship

# Importamos Base y Escola2.
from Escola2 import Base, Escola2

# Importamos Profesor2.
from Profesor2 import Profesor2


# CLASE ALUMNO2

class Alumno2(Base):

    # Nombre de la tabla en SQLite.
    __tablename__ = "alumnos2"

    # Identificador único del alumno.
    id = Column(Integer, primary_key=True)

    # Nombre del alumno.
    nombre = Column(String, nullable=False)

    # Curso del alumno.
    curso = Column(String, nullable=False)

    # Grupo al que pertenece.
    grupo = Column(String, nullable=False)


    # RELACIÓN CON ESCOLA2

    # ID de la escuela a la que pertenece el alumno.
    escola_id = Column(
        Integer,
        ForeignKey("escoles2.id"),
        nullable=False
    )

    # Relación entre Alumno2 y Escola2.
    escola = relationship("Escola2")


    # RELACIÓN CON PROFESOR2

    # ID del profesor responsable del alumno.
    profesor_id = Column(
        Integer,
        ForeignKey("profesores2.id"),
        nullable=False
    )

    # Relación entre Alumno2 y Profesor2.
    profesor = relationship("Profesor2")


    # CONSTRUCTOR

    def __init__(
        self,
        nombre,
        curso,
        grupo,
        escola,
        profesor
    ):

        self.nombre = nombre
        self.curso = curso
        self.grupo = grupo

        # Guardamos la escuela relacionada.
        self.escola = escola

        # Guardamos el profesor responsable.
        self.profesor = profesor


    # MOSTRAR INFORMACIÓN

    def __str__(self):

        return (
            f"Alumno: {self.nombre} | "
            f"Curso: {self.curso} | "
            f"Grupo: {self.grupo} | "
            f"Profesor: {self.profesor.nombre}"
        )