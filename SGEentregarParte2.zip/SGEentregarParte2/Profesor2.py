# CLASE PROFESOR - ACTIVIDAD 06

# Importamos las herramientas de SQLAlchemy.
from sqlalchemy import Column, Integer, String, ForeignKey

# relationship() permite establecer relaciones
# entre nuestras clases.
from sqlalchemy.orm import relationship

# Importamos Base y Escola2 desde Escola2.py.
from Escola2 import Base, Escola2


# CLASE PROFESOR2

class Profesor2(Base):

    # Nombre de la tabla en SQLite.
    __tablename__ = "profesores2"

    # Identificador único del profesor.
    id = Column(Integer, primary_key=True)

    # Nombre del profesor.
    nombre = Column(String, nullable=False)

    # Tipo de profesor.
    # Puede ser ciencias, letras o mixto.
    tipo = Column(String, nullable=False)


    # RELACIÓN CON ESCOLA2

    # Guardamos el ID de la escuela a la que pertenece
    # el profesor.
    escola_id = Column(
        Integer,
        ForeignKey("escoles2.id"),
        nullable=False
    )

    # Creamos la relación entre Profesor2 y Escola2.
    escola = relationship("Escola2")


    # CONSTRUCTOR

    def __init__(self, nombre, tipo, escola):

        self.nombre = nombre
        self.tipo = tipo

        # Guardamos la escuela relacionada.
        self.escola = escola


    # MOSTRAR INFORMACIÓN

    def __str__(self):

        return (
            f"Profesor: {self.nombre} | "
            f"Tipo: {self.tipo}"
        )